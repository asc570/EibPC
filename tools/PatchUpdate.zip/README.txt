README
------

Please read carefully!

++++ ATTENTION ++++
    * You need at least patch version 2.314 on your EibPC to install this patch.
    * You need the license key V3 (code 0x500006). Otherwise the EibPC will stop working!
    * Please clear the browser cache after patching

ChangeLog
---------
Patch 3.107  (2017-10-10)
    * Firmware:
        - bugfix: timers stime, mtime, htime, wtime leading to false triggers in special cases
        - bugfix: update of link and plink elements with custom HTML code leading to JSON errors
        
Patch 3.106  (2017-10-04)
    * Firmware:
        - improved debugging of JSON messages
        
Patch 3.105  (2017-09-05)
    * Firmware:
        - OpenVPN update
        
Patch 3.104  (2017-05-19)
    * Webserver:
        - bugfix: width of picture element
        - bugfix: webdaemon bug leading to a json error
        - bugfix: weboutput styles ICON and NOCOLOR were not avaiable
        - bugfix: username and password was limited to 7 characters
        - bugfix: incorrect view of some elements in compact mode
    * Known issues:
        - timechart axis indices sometimes overlap 
        
Patch 3.103  (2017-04-24)
    * Webserver:
        - picture element visualization tweaked
    * Known issues:
        - timechart axis indices sometimes overlap

Patch 3.102  (2017-04-03)
    * Firmware:
        - RS232 functions have needed option NP by mistake
    * Known issues:
        - timechart axis indices sometimes overlap

Patch 3.101  (2016-07-27)
    * Webserver:
        - timechart "pan and zoom" works again
    * Known issues:
        - timechart axis indices sometimes overlap

Patch 3.100  (2016-07-20)
    * Firmware:
        - A timer bug was fixed
        - new nconf argument "-Y" added
    * Known issues:
        - timechart axis indices sometimes overlap

Patch 3.060  (2016-06-16)
    * Firmware:
        - mtimechart and mtimechartpos functions do not abort on empty timebuffers
        - timebufferclear function added
        - writeflashvar funtion added
        - readflashvar funtion added
        - easterday function added
        - eastermonth function added
        - a event code bug was fixed
    * Known issues:
        - timechart axis indices sometimes overlap

Patch 3.059  (2016-05-25)
    * Webserver
        - some timechart glitches fixed
        - mpchart issues fixed
    * Known issues:
        - timechart axis indices sometimes overlap

Patch 3.058  (2016-05-13) Friday the 13th edition
    * Webserver
        - empty spaces when using dframe fixed
        - internal server error on large pages with a lot of none elements fixed
        - some timechart glitches fixed

Patch 3.057  (2016-05-10)
    * Webserver
        - broken navigation menu fixed
        - broken user defined header fixed
        - broken footer fixed
    * Known issues:
        - timechart x-axis indices are cut off

Patch 3.056  (2016-05-04)
    * Webserver
        - text overflowing button fixed
        - a Safari issue fixed
        - slightly faster page rendering in the browser
    * Known issues:
        - timechart x-axis indices are cut off

Patch 3.055  (2016-04-27)
    * Webserver
        - slider text input field too small on iOS fixed
        - weboutput css reworked
        - empty space besides web page on small screens fixed
        - timecharts always showing maximum number of values after update fixed
        - a glitch in the header of the black design was fixed
        - slightly finer graph lines for timecharts
        - mtimechartpos function works now
        - mtimechart function works now
        - flot JS library updated to v0.8.3
    * Firmware:
        - some event names changed for various functions

Patch 3.054  (2016-04-05)
    * Firmware:
        - event names changed for tcp/udp functions
        - fixed a possible firmware crash with old eib-config

Patch 3.053  (2016-04-04)
    * Webserver:
        - now there can be more small web elements beside a large web element, so there is no
          empty space anymore
        - more webinputs (password, date, time, color)
        - fixed a bug where cgi was run twice
        - more weboutputs (sizes, design)
        - eib-config parsing reworked for web server section (recompile your program with latest EibStudio!)

Patch 3.027  (2015-12-18)
    * Firmware:
        - default port assignment fixed
        - firmware tries to use default ports if user defined ports fail to bind
    * Webserver:
        - some more optimizations for time charts
        - time chart graph regression fixed

Patch 3.026  (2015-12-16)
    * Webserver:
        - faster loading times for web pages with time charts

Patch 3.025  (2015-12-03)
    * Firmware:
        - generate event on wrong port setting
        - sending and receiving from same UDP is port possible now

Patch 3.024  (2015-11-27)
    * Firmware:
        - mtimechart graph colors can be defined by the user
        - Fixed a bug where sendtcp/sendtcparray did not work the first time after systemstart
        - TCP/UDP ports can be defined by the user
        - E-Mail client has slightly higher priority now + small optimizations

Patch 3.023  (2015-07-27)
    * Firmware:
        - When webserver is used the telegram log buffer is reduced to 150000 on firmware start
        - Optimized memory management
        - Fixed a bug where firmware hung up on converting a string from c1400 to c65534
        - Fixed a bug where the tostring function did not work
    * Webserver:
        - A new http daemon is used
    * Known Bugs:
        + Webserver: incorrect slider value on mobile safari and chrome

Patch 3.022  (2015-05-08)
    * Firmware:
        - fixed a bug with toString() function (in combination with eibparser 3.021)
        - fixed a bug which forced the EibPC in a reboot loop
        - changed the internal behaviour of initga
    * Known Bugs:
        + Webserver: incorrect slider value on mobile safari and chrome

Patch 3.021  (2015-03-30)
    * Webserver Bugfixes:
        - line element: correction of font colour and size
        - picture element: display problem fixed
        - mchart: larger bar graphs

Patch 3.020  (2015-03-13)
	* Firmware:
		- Improved performance using encoding functions
		- Optimized memory management
		- Bugfix in function "getGAName"
		- New Function: ToString()
	* Webserver Bugfixes:
		- None elements are no longer counted
		- picture element: fixed a display problem when using a HALF sized picture element
		- timechart: fixed a display problem when using multiple charts on one page
		- timechart: fixed a display problem when using timebuffers configured as ring buffer ("return-line-problem")
		- multiwebchart: changed bar width


Patch 3.019  (2014-12-19)
	* Webserver Bugfixes:
		- mchart: changed bar width to avoid overlap
		- mpbutton: index update didn't work
		- weboutput: weboutput was empty after page refresh
	* Webserver Features:
		- Up to 60 Elements per page
		- Improved password protection
		- new mobilezoom function for individual adjustment to your mobile device /
			browser; use in webserver section: mobilezoom(zoomfactor in percent) – e.g.:
			mobilezoom(200)

Patch 3.018  (2014-06-11)
    * PKI key length increased to 2048 bits
    * fixed problems with webelement ID 0
    * fixed problems with webpage IDs >=60

Patch 3.017  (2014-31-10)
    * security patches of Linux system
    * new security keys now with 1536 bits
    * firmware memory cleaner tweaked (better low memory limit detection)

Patch 3.015  (2014-07-25)
    * bug fixed: "no timechart is shown in visu after timebufferread"
    * bug fixed: "no timechart is shown in visu for 1 bit timebuffer data types"
    * bug fixed: "scene function reads last GA twice"
    * firmware memory cleaner tweaked
    * Chrome web app capability added to visu: https://developer.chrome.com/multidevice/android/installtohomescreen

Patch 3.014  (2014-07-18)
    * better handling of low memory situations
    * memory for telegram buffer and timecharts will be completely allocated at firmware start
    * if memory runs low during runtime the firmware empties telegram buffer and reduces it's maximum size
    * estimated size of memory left for the firmware can be received with "nconf -i"

Patch 3.013  (2014-07-09)
    * memory handling tweaked

Patch 3.012  (2014-06-17)
    * size() results in wrong values, if string is bigger than 1400 characters

Patch 3.011  (2014-06-03)
    * sending mails with various German mail providers fixed
    * mbutton index bug fixed

Patch 3.010  (2014-05-08)
    * priority of firmware threads changed
    * peslider bug fixed

Patch 3.009  (2014-04-07)
    * during ftp transfer a subdir will be created if it does not exist before
    * icons 37-43, 59, 61, 62 fixed

Patch 3.008  (2014-04-02)
    * a bug where wrong web elements have been updated was fixed
    * many code changes to reduce memory usage
    * JavaScript size reduced

Patch 3.007  (2014-03-28)
    * timechart behaviour tweaked
    * new icons
    * average CPU usage added to nconf -i

Patch 3.006  (2014-03-26)
    * a lot of firmware/rt-visu code rewritten for better performance and stability
    * less memory usage
    * faster rt-visu responses
    * a crashed firmware should be automatically respawned now

Patch 3.004  (2014-02-21)
    * rt-visu: bugfix in interprocess communication between FW and rt-visu-daemon leading to blockade of rt-visu-daemon
    				new Icons (have a look at the manual)


Patch 3.003  (2014-02-14)
    * rt-visu: bugfix in timechart update process causing crash of the rt-visu-daemon


Patch 3.002  (2014-02-11)
    * rt-visu: changed order in html title
    				bugfix in interprocess communication (semaphor error led to blockade of FW and rt-visu-daemon)


Patch 3.001  (2014-01-30)
    * rt-visu: bugfix timechart y-axis limits
    				bugfix timechart (index corruption if more than one timechart and some buttons on one page leading to update failure)
    				bugfix multibuttons (didn't swap to the selected index in some browsers)
    				HTML Code with quotation marks in status updates doesn't make problems any more
    				real-time daemon code more failsafe
    * FW Upgrade -> 3.001 (nconf fix)


Patch 3.000  (2014-01-16)
    * rt-visu: fully implemented real time visualization.
               Please read manual for new functionality and new elements
    * KNOWN ISSUE: timechart does not support u08 values at the moment; if necessary please use the convert() function to convert to f16
